package cn.sherven.query.result;

public class TimeSeriesRecommendResult {
    private String leaf1, leaf3;
    private int english, steplevel;

    public String getLeaf1() {
        return leaf1;
    }

    public void setLeaf1(String leaf1) {
        this.leaf1 = leaf1;
    }

    public String getLeaf3() {
        return leaf3;
    }

    public void setLeaf3(String leaf3) {
        this.leaf3 = leaf3;
    }

    public int getEnglish() {
        return english;
    }

    public void setEnglish(int english) {
        this.english = english;
    }

    public int getSteplevel() {
        return steplevel;
    }

    public void setSteplevel(int steplevel) {
        this.steplevel = steplevel;
    }
}
