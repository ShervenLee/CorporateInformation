package cn.sherven.query.result;

public class UserSimilarityRecommendResult {
    private String NSCHOOLID, SSTUDENTCODE, COURSE_COUNT, DTBIRTHDAY, NGENDER, BADULT, SNAME;

    public String getNSCHOOLID() {
        return NSCHOOLID;
    }

    public void setNSCHOOLID(String NSCHOOLID) {
        this.NSCHOOLID = NSCHOOLID;
    }

    public String getSSTUDENTCODE() {
        return SSTUDENTCODE;
    }

    public void setSSTUDENTCODE(String SSTUDENTCODE) {
        this.SSTUDENTCODE = SSTUDENTCODE;
    }

    public String getCOURSE_COUNT() {
        return COURSE_COUNT;
    }

    public void setCOURSE_COUNT(String COURSE_COUNT) {
        this.COURSE_COUNT = COURSE_COUNT;
    }

    public String getDTBIRTHDAY() {
        return DTBIRTHDAY;
    }

    public void setDTBIRTHDAY(String DTBIRTHDAY) {
        this.DTBIRTHDAY = DTBIRTHDAY;
    }

    public String getNGENDER() {
        return NGENDER;
    }

    public void setNGENDER(String NGENDER) {
        this.NGENDER = NGENDER;
    }

    public String getBADULT() {
        return BADULT;
    }

    public void setBADULT(String BADULT) {
        this.BADULT = BADULT;
    }

    public String getSNAME() {
        return SNAME;
    }

    public void setSNAME(String SNAME) {
        this.SNAME = SNAME;
    }
}
