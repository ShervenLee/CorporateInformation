package cn.sherven.query;

public class TimeSeriesRecommendQuery {
    private String  coursecode;
    private int nschoolid;

    public String getCoursecode() {
        return coursecode;
    }

    public void setCoursecode(String coursecode) {
        this.coursecode = coursecode;
    }

    public int getNschoolid() {
        return nschoolid;
    }

    public void setNschoolid(int nschoolid) {
        this.nschoolid = nschoolid;
    }
}
